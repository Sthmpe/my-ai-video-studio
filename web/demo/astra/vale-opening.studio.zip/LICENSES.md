# Asset licences & attribution
* Video model: AnimateDiff-Lightning (ByteDance) — Apache-2.0.
* Base image models: ToonYou β6 / Counterfeit-V2.5 — CreativeML OpenRAIL-M (use restrictions apply; see model cards).
* VAE: stabilityai/sd-vae-ft-mse — MIT. IP-Adapter (h94) — Apache-2.0. Motion LoRAs (guoyww) — Apache-2.0.
* Voice: Kokoro-82M — Apache-2.0. Japanese G2P: misaki + pyopenjtalk + unidic-lite (BSD/MIT-style).
* Music & sound effects: procedurally synthesised by this engine — original, no third-party samples.
* Script: as recorded in story/script.json (`author`, `credits`). Wikipedia-derived text is CC BY-SA 4.0.
* Characters: original unless story/script.json `rights_note` says user-supplied references were used.
